using PadraoPattern;
using System.ComponentModel;

namespace PetternText
{
    public class Regra4Teste
    {
        [Fact]
        public void SudesteScoreMenorRetornaTrue()
        {
           
            Conta mockConta = new Conta();
            mockConta.Score = 199;
            TransacaoBancaria transacao = new TransacaoBancaria();
            transacao.AgenciaTransacao = "MG";

            IBloquearConta processarBloqueio = new Regra4Bloqueio();

            bool resultado = processarBloqueio.analiseBloqueio(mockConta, transacao);

            Assert.True(resultado);
        }

        [Fact]
        public void NaoSudesteScoreMenorRetornaTrue()
        {
          
            Conta mockConta = new Conta();
            mockConta.Score = 100;
            TransacaoBancaria transacao = new TransacaoBancaria();
            transacao.AgenciaTransacao = "SE";

            IBloquearConta processarBloqueio = new Regra4Bloqueio();

            bool resultado = processarBloqueio.analiseBloqueio(mockConta, transacao);

            Assert.False(resultado);
        }

    }
}